'use strict';

// background.js — Executive Copywriting, Profile Fit & 3-Layer AI Pipeline
// Supports Free Mode (structured local heuristics) and AI Mode (Anthropic API + cached PDF resume).

const ANTHROPIC_URL = 'https://api.anthropic.com/v1/messages';
const DEFAULT_MODEL = 'claude-haiku-5-5';

// ─── Router ───────────────────────────────────────────────────────────────────
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {

  if (message.action === 'scrapeProfile') {
    handleScrapeProfile(sendResponse);
    return true;
  }

  if (message.action === 'generateMessage') {
    handleQuickGenerate(message.data, sendResponse);
    return true;
  }

  if (message.type === 'TEST_API_KEY') {
    handleTestKey(message.payload, sendResponse);
    return true;
  }

  if (message.type === 'PARSE_RESUME') {
    handleParseResume(message.payload, sendResponse);
    return true;
  }

  if (message.type === 'RUN_ENRICH') {
    handleEnrich(message.payload, sendResponse);
    return true;
  }

  if (message.type === 'RUN_GENERATE') {
    handleDeepGenerate(message.payload, sendResponse);
    return true;
  }

  if (message.type === 'SHORTEN_MESSAGE') {
    handleShortenMessage(message.payload, sendResponse);
    return true;
  }

  if (message.type === 'SAVE_RECENT') {
    chrome.storage.local.get(['recentContacts'], (result) => {
      const recent = result.recentContacts || [];
      const updated = [message.payload, ...recent.filter(c => c.profileUrl !== message.payload.profileUrl)].slice(0, 5);
      chrome.storage.local.set({ recentContacts: updated });
      sendResponse({ status: 'saved' });
    });
    return true;
  }

  if (message.type === 'GET_RECENT') {
    chrome.storage.local.get(['recentContacts'], (result) => {
      sendResponse({ contacts: result.recentContacts || [] });
    });
    return true;
  }
});

// ─── Scrape profile from active tab (top frame only) ──────────────────────────
async function handleScrapeProfile(sendResponse) {
  try {
    const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
    const tab = tabs[0];
    if (!tab) throw new Error('No active tab found.');
    if (!tab.url || !tab.url.includes('linkedin.com')) {
      throw new Error('Please navigate to a LinkedIn profile page first.');
    }

    let result;
    try {
      result = await chrome.tabs.sendMessage(tab.id, { action: 'scrapeProfile' }, { frameId: 0 });
    } catch (_) {
      await chrome.scripting.executeScript({ target: { tabId: tab.id, allFrames: true }, files: ['content_script.js'] });
      await delay(400);
      result = await chrome.tabs.sendMessage(tab.id, { action: 'scrapeProfile' }, { frameId: 0 });
    }

    if (!result?.success) throw new Error(result?.error || 'Scrape failed.');
    sendResponse({ success: true, data: result.data });
  } catch (err) {
    sendResponse({ success: false, error: err.message });
  }
}

// ─── Test user's own API key ──────────────────────────────────────────────────
async function handleTestKey({ apiKey, model }, sendResponse) {
  try {
    const chosenModel = model || (await getStoredModel());
    await callClaude(apiKey, 'Reply with the single word: OK', 10, chosenModel);
    sendResponse({ valid: true, model: chosenModel });
  } catch (err) {
    sendResponse({ valid: false, reason: err.message });
  }
}

// ─── Parse uploaded PDF resume into a cached summary ──────────────────────────
async function handleParseResume({ resumeBase64, resumeFileName }, sendResponse) {
  try {
    const apiKey = await getApiKey();
    if (!apiKey) {
      sendResponse({
        success: true,
        cached: false,
        reason: 'PDF saved locally. Add an Anthropic API key to auto-extract skills and highlights.'
      });
      return;
    }

    const model = await getStoredModel();
    const contentBlocks = [
      {
        type: 'document',
        source: {
          type: 'base64',
          media_type: 'application/pdf',
          data: resumeBase64
        }
      },
      {
        type: 'text',
        text: `Extract a high-impact sender profile from this resume for executive LinkedIn outreach.
Return ONLY valid JSON with these exact keys (no markdown fences):
{
  "headline": "1-line role/specialty summary",
  "skills": ["skill1", "skill2", "skill3", "skill4", "skill5", "skill6"],
  "highlights": ["quantified achievement or shipped system 1", "quantified achievement 2"],
  "summary": "1-sentence punchy credibility statement (under 140 chars)"
}`
      }
    ];

    const raw = await callClaude(apiKey, contentBlocks, 450, model);
    const parsed = parseSafeJSON(raw);

    const resumeSummary = {
      fileName: resumeFileName || 'Resume.pdf',
      headline: String(parsed.headline || '').trim(),
      skills: Array.isArray(parsed.skills) ? parsed.skills.slice(0, 8) : [],
      highlights: Array.isArray(parsed.highlights) ? parsed.highlights.slice(0, 3) : [],
      summary: String(parsed.summary || '').trim(),
      parsedAt: Date.now()
    };

    await new Promise(resolve => chrome.storage.local.set({ resumeSummary }, resolve));
    sendResponse({ success: true, cached: true, resumeSummary });
  } catch (err) {
    sendResponse({ success: false, error: err.message });
  }
}

// ─── Quick Mode generate ──────────────────────────────────────────────────────
async function handleQuickGenerate(data, sendResponse) {
  try {
    const { profileData, settings, messageType, tone, customContext, maxChars = 300 } = data;
    const p = normalizeProfile(profileData);
    const hooks = buildQuickHooks(p, settings?.resumeSummary);
    const apiKey = await getApiKey();
    const model = settings?.claudeModel || (await getStoredModel());

    const result = apiKey
      ? await aiStructuredMessage(apiKey, p, hooks, messageType, tone, settings, model, customContext, maxChars)
      : localExecutiveMessage(p, hooks, messageType, tone, settings, customContext, maxChars);

    sendResponse({
      success: true,
      generatedMessage: result.message,
      structuredMeta: result.meta
    });
  } catch (err) {
    sendResponse({ success: false, error: err.message });
  }
}

// ─── Deep Mode enrich (L1 + L2 + Profile Fit & Talking Points) ────────────────
async function handleEnrich({ rawProfileData }, sendResponse) {
  try {
    const stored = await new Promise(resolve =>
      chrome.storage.local.get(['userName', 'userBio', 'resumeSummary', 'claudeModel'], resolve)
    );
    const baseProfile = normalizeProfile(rawProfileData);
    const apiKey = await getApiKey();
    const model = stored.claudeModel || DEFAULT_MODEL;

    if (!apiKey) {
      const hooks = buildCategorizedLocalHooks(baseProfile, stored.resumeSummary);
      const profileFit = buildProfileFitLocal(baseProfile, stored.resumeSummary, stored.userBio);
      await delay(250);
      sendResponse({
        status: 'enrich_complete',
        mode: 'free',
        profileJSON: {
          ...baseProfile,
          inferredSeniority: inferSeniorityLocal(baseProfile.currentTitle || baseProfile.headline),
          domainFocus: baseProfile.skills.slice(0, 3).join(', ') || cleanHeadlineFocus(baseProfile.headline)
        },
        enrichmentJSON: { topHooks: hooks, profileFit }
      });
      return;
    }

    const senderSummary = {
      name: stored.userName || '',
      bio: stored.userBio || '',
      resumeHeadline: stored.resumeSummary?.headline || '',
      resumeSummary: stored.resumeSummary?.summary || '',
      resumeSkills: stored.resumeSummary?.skills || [],
      resumeHighlights: stored.resumeSummary?.highlights || []
    };

    const prompt =
`You are performing Layer 1 (Profile Parser), Layer 2 (Outreach Angle Extractor), and Sender-Prospect Fit Analysis.
Analyze the raw scraped LinkedIn profile and the sender's background/resume.

Raw Recipient Profile:
${JSON.stringify({
  name: baseProfile.name,
  headline: baseProfile.headline,
  currentTitle: baseProfile.currentTitle,
  currentCompany: baseProfile.currentCompany,
  location: baseProfile.location,
  about: truncate(baseProfile.about, 600),
  experienceEntries: baseProfile.experienceEntries,
  educationEntries: baseProfile.educationEntries,
  skills: baseProfile.skills,
  recentPosts: baseProfile.recentPosts
})}

Sender Background:
${JSON.stringify(senderSummary)}

Return ONLY valid JSON (no markdown fences) matching this exact schema:
{
  "profile": {
    "cleanTitle": "normalized current job title",
    "cleanCompany": "normalized current company",
    "seniority": "e.g., IC / Senior / Lead / Manager / Director / Founder / Student",
    "domainFocus": "1-line summary of what they actually build, research, or lead"
  },
  "hooks": [
    {
      "category": "Shared Stack | Recent Activity | Company/Role | Background",
      "strength": "High | Medium",
      "text": "Specific, factual 1-sentence outreach hook grounded strictly in the profile/resume (never paste raw pipe-separated headlines)"
    }
  ],
  "profileFit": {
    "fitLabel": "Strong Resume Overlap | Direct Skill Match | Adjacent Technical Domain",
    "matchedSkills": ["overlapping skill or domain 1", "overlapping skill 2"],
    "talkingPoints": [
      "1 crisp talking point connecting sender's resume/projects to recipient's current work",
      "1 sharp question or angle to use once they reply"
    ]
  }
}
Provide 3 to 4 distinct hooks ranked by relevance.`;

    const raw = await callClaude(apiKey, prompt, 750, model);
    const parsed = parseSafeJSON(raw);

    const profileJSON = {
      ...baseProfile,
      currentTitle: parsed.profile?.cleanTitle || baseProfile.currentTitle,
      currentCompany: parsed.profile?.cleanCompany || baseProfile.currentCompany,
      inferredSeniority: parsed.profile?.seniority || '',
      domainFocus: parsed.profile?.domainFocus || ''
    };

    const topHooks = Array.isArray(parsed.hooks) && parsed.hooks.length
      ? parsed.hooks.slice(0, 4).map(h => ({
          category: String(h.category || 'Profile'),
          strength: String(h.strength || 'High'),
          text: String(h.text || '').trim()
        })).filter(h => h.text)
      : buildCategorizedLocalHooks(profileJSON, stored.resumeSummary);

    const fallbackFit = buildProfileFitLocal(profileJSON, stored.resumeSummary, stored.userBio);
    const profileFit = parsed.profileFit?.talkingPoints?.length
      ? {
          fitLabel: String(parsed.profileFit.fitLabel || fallbackFit.fitLabel),
          matchedSkills: Array.isArray(parsed.profileFit.matchedSkills)
            ? parsed.profileFit.matchedSkills.slice(0, 5)
            : fallbackFit.matchedSkills,
          talkingPoints: parsed.profileFit.talkingPoints.slice(0, 2).map(t => String(t).trim()).filter(Boolean)
        }
      : fallbackFit;

    sendResponse({
      status: 'enrich_complete',
      mode: 'ai',
      profileJSON,
      enrichmentJSON: { topHooks, profileFit }
    });
  } catch (err) {
    sendResponse({ status: 'error', error: err.message });
  }
}

// ─── Deep Mode generate (L3) ──────────────────────────────────────────────────
async function handleDeepGenerate({ profileJSON, selectedHooks, customContext, messageType, tone, maxChars = 300 }, sendResponse) {
  try {
    const settings = await new Promise(resolve =>
      chrome.storage.local.get(['userName', 'userBio', 'resumeSummary', 'claudeModel'], resolve)
    );
    const hookTexts = (selectedHooks || [])
      .map(h => (typeof h === 'string' ? h : h.text))
      .filter(Boolean);

    const apiKey = await getApiKey();
    const model = settings.claudeModel || DEFAULT_MODEL;

    const result = apiKey
      ? await aiStructuredMessage(apiKey, profileJSON, hookTexts, messageType, tone, settings, model, customContext, maxChars)
      : localExecutiveMessage(profileJSON, hookTexts, messageType, tone, settings, customContext, maxChars);

    sendResponse({
      status: 'generate_complete',
      generatedMessage: result.message,
      structuredMeta: result.meta
    });
  } catch (err) {
    sendResponse({ status: 'error', error: err.message });
  }
}

// ─── Shorten over-limit message while preserving hook & CTA ───────────────────
async function handleShortenMessage({ text, maxChars = 300, tone }, sendResponse) {
  try {
    const apiKey = await getApiKey();
    const model = await getStoredModel();

    if (!apiKey) {
      const trimmed = smartTrimToLimit(text, maxChars);
      sendResponse({ success: true, shortenedMessage: trimmed });
      return;
    }

    const prompt =
`Tighten the following LinkedIn outreach message so it is STRICTLY under ${maxChars} characters (including line breaks).
Keep its crisp executive structure (Greeting + Sharp Hook + Specific CTA + Sign-off). Maintain a ${tone || 'Neutral'} tone.
Return ONLY the tightened message text, nothing else.

Message:
${text}`;

    let shortened = (await callClaude(apiKey, prompt, 250, model)).trim();
    if (shortened.length > maxChars) {
      shortened = smartTrimToLimit(shortened, maxChars);
    }
    sendResponse({ success: true, shortenedMessage: shortened });
  } catch (err) {
    sendResponse({ success: false, error: err.message });
  }
}

// ─── Profile, Hook & Fit helpers ──────────────────────────────────────────────
function normalizeProfile(raw = {}) {
  return {
    name: (raw.name || '').trim(),
    firstName: ((raw.name || '').trim().split(/\s+/)[0]) || 'there',
    headline: raw.headline || '',
    currentTitle: raw.currentTitle || '',
    currentCompany: raw.currentCompany || '',
    location: raw.location || '',
    about: raw.about || '',
    recentPosts: raw.recentPosts || [],
    experienceEntries: raw.experienceEntries || [],
    pastCompanies: raw.pastCompanies || [],
    educationEntries: raw.educationEntries || [],
    skills: raw.skills || [],
    profileUrl: raw.profileUrl || ''
  };
}

function cleanHeadlineFocus(headline = '') {
  if (!headline) return 'your domain';
  const firstClause = headline.split(/[|•·]/)[0].trim();
  return truncate(firstClause || headline, 65);
}

function findSharedSkills(recipientSkills = [], resumeSummary = null) {
  if (!resumeSummary?.skills?.length || !recipientSkills.length) return [];
  const senderLower = resumeSummary.skills.map(s => s.toLowerCase());
  return recipientSkills.filter(rs =>
    senderLower.some(ss => ss === rs.toLowerCase() || rs.toLowerCase().includes(ss) || ss.includes(rs.toLowerCase()))
  );
}

function buildProfileFitLocal(p, resumeSummary = null, userBio = '') {
  const shared = findSharedSkills(p.skills, resumeSummary);
  const focus = cleanHeadlineFocus(p.currentTitle || p.headline);
  const senderSkills = resumeSummary?.skills?.slice(0, 3) || [];
  const fitLabel = shared.length >= 2
    ? 'Strong Resume Overlap'
    : shared.length === 1
      ? 'Direct Skill Match'
      : 'Adjacent Technical Domain';

  const tp1 = shared.length
    ? `Highlight hands-on experience in ${shared.slice(0, 3).join(', ')} matching ${p.firstName}'s stack.`
    : senderSkills.length
      ? `Bridge your ${senderSkills.join(', ')} background to ${p.firstName}'s focus on ${focus}.`
      : userBio
        ? `Connect your background (${truncate(userBio, 65)}) to ${p.firstName}'s work in ${focus}.`
        : `Lead with curiosity around ${p.firstName}'s ${focus} work${p.currentCompany ? ' at ' + p.currentCompany : ''}.`;

  const tp2 = p.recentPosts.length
    ? `Follow up on their post regarding "${truncate(cleanHeadlineFocus(p.recentPosts[0]), 55)}".`
    : `Ask about current engineering priorities or challenges in ${focus}.`;

  return {
    fitLabel,
    matchedSkills: shared.slice(0, 5),
    talkingPoints: [tp1, tp2]
  };
}

function buildQuickHooks(p, resumeSummary = null) {
  const hooks = [];
  const shared = findSharedSkills(p.skills, resumeSummary);
  if (shared.length) hooks.push(`Shared technical focus in ${shared.slice(0, 2).join(' & ')}`);
  if (p.recentPosts.length) hooks.push(`Recent post on "${truncate(cleanHeadlineFocus(p.recentPosts[0]), 70)}"`);
  if (p.currentTitle && p.currentCompany) hooks.push(`Leading ${p.currentTitle} work at ${p.currentCompany}`);
  else if (p.currentCompany) hooks.push(`Building at ${p.currentCompany}`);
  if (p.skills.length) hooks.push(`Core expertise in ${p.skills.slice(0, 3).join(', ')}`);
  if (p.pastCompanies.length) hooks.push(`Prior experience at ${p.pastCompanies.slice(0, 2).join(' and ')}`);
  if (!hooks.length && p.headline) hooks.push(`Focus on ${cleanHeadlineFocus(p.headline)}`);
  return hooks.slice(0, 3);
}

function inferSeniorityLocal(title = '') {
  if (/founder|ceo|cto|vp|vice president|head of|director/i.test(title)) return 'Leadership';
  if (/manager|lead|principal|staff/i.test(title)) return 'Senior / Lead';
  if (/intern|student|fellow|trainee/i.test(title)) return 'Early Career';
  return 'Individual Contributor';
}

function buildCategorizedLocalHooks(p, resumeSummary = null) {
  const hooks = [];
  const shared = findSharedSkills(p.skills, resumeSummary);
  if (shared.length) {
    hooks.push({
      category: 'Shared Stack',
      strength: 'High',
      text: `Both build with ${shared.slice(0, 3).join(', ')}`
    });
  }
  if (p.recentPosts.length) {
    hooks.push({
      category: 'Recent Activity',
      strength: 'High',
      text: `Shared insights on "${truncate(cleanHeadlineFocus(p.recentPosts[0]), 75)}"`
    });
  }
  if (p.currentTitle && p.currentCompany) {
    hooks.push({
      category: 'Company/Role',
      strength: 'High',
      text: `Driving ${p.currentTitle} initiatives at ${p.currentCompany}`
    });
  } else if (p.headline) {
    hooks.push({
      category: 'Domain Focus',
      strength: 'High',
      text: `Focused on ${cleanHeadlineFocus(p.headline)}`
    });
  }
  if (p.skills.length) {
    hooks.push({
      category: 'Tech Stack',
      strength: 'Medium',
      text: `Hands-on depth in ${p.skills.slice(0, 3).join(', ')}`
    });
  }
  if (p.pastCompanies.length && hooks.length < 4) {
    hooks.push({
      category: 'Background',
      strength: 'Medium',
      text: `Previously built at ${p.pastCompanies.slice(0, 2).join(' and ')}`
    });
  }
  return hooks.slice(0, 4);
}

// ─── High-Standard Executive Copywriting Engine (Free Mode) ───────────────────
function localExecutiveMessage(p, hooks, messageType, tone, settings = {}, customContext = '', maxChars = 300) {
  const me = (settings.userName || '').trim();
  const resume = settings.resumeSummary || null;
  const rawBio = (settings.userBio || '').trim() || (resume?.summary || '').trim();
  const co = p.currentCompany ? ` at ${p.currentCompany}` : '';
  const focus = cleanHeadlineFocus(p.currentTitle || p.headline);
  const custom = (customContext || '').trim();
  const isShortNote = maxChars <= 300;

  const greeting = {
    Formal: `Hi ${p.firstName},`,
    Neutral: `Hi ${p.firstName},`,
    Casual: `Hey ${p.firstName},`
  }[tone] || `Hi ${p.firstName},`;

  const signOff = {
    Formal: 'Best regards,',
    Neutral: 'Best,',
    Casual: 'Cheers,'
  }[tone] || 'Best,';

  let hookAngle = 'Domain Focus';
  let hookLine = `Your work around ${focus}${co} caught my attention.`;

  if (hooks && hooks.length) {
    const h = hooks[0].replace(/\.$/, '');
    if (/shared insights on|posted about|recent post/i.test(h)) {
      hookAngle = 'Recent Activity';
      const topic = h.replace(/^(shared insights on|posted about|recent post on)\s*/i, '');
      hookLine = `Your recent perspective on ${topic} really resonated.`;
    } else if (/both build with|shared technical/i.test(h)) {
      hookAngle = 'Shared Stack';
      const stack = h.replace(/^(both build with|shared technical focus in)\s*/i, '');
      hookLine = `Great seeing another builder working hands-on with ${stack}.`;
    } else if (/driving|leading|currently/i.test(h)) {
      hookAngle = 'Role & Impact';
      hookLine = `Following your ${focus} work${co}—especially how you're scaling practical systems.`;
    } else {
      hookAngle = 'Domain Focus';
      hookLine = `Your focus on ${focus}${co} stood out immediately.`;
    }
  }

  let bridgeLine = '';
  if (custom) {
    bridgeLine = custom.endsWith('.') ? custom : `${custom}.`;
  } else if (!isShortNote && rawBio) {
    bridgeLine = `On my end, I'm ${truncate(rawBio.replace(/^i am\s+|^i'm\s+/i, ''), 115)}`;
  } else if (!isShortNote && resume?.skills?.length) {
    bridgeLine = `I've been shipping AI/ML products across ${resume.skills.slice(0, 3).join(', ')}.`;
  }

  const ctaLine = {
    Networking: `Open to connecting and trading notes on ${focus.split(' ')[0]}?`,
    Job: `Would love to connect—are you open to a brief chat on AI/ML roles${co}?`,
    Referral: `Would appreciate 2 minutes of your perspective on engineering openings${co}.`,
    Collaboration: `Would love to connect and explore potential ways to collaborate.`
  }[messageType] || `Would love to connect and stay in touch.`;

  const signature = me ? `${signOff} ${me}` : signOff;

  const assembled = isShortNote
    ? `${greeting}\n\n${hookLine}${bridgeLine ? ' ' + bridgeLine : ''} ${ctaLine}\n\n${signature}`
    : `${greeting}\n\n${hookLine}${bridgeLine ? '\n\n' + bridgeLine : ''}\n\n${ctaLine}\n\n${signOff}${me ? '\n' + me : ''}`;

  const finalMessage = smartTrimToLimit(assembled, maxChars);

  return {
    message: finalMessage,
    meta: {
      angle: hookAngle,
      channelLabel: isShortNote ? 'Connection Note' : 'Direct Message',
      structure: isShortNote ? 'Hook → Micro-CTA' : 'Hook → Credibility Bridge → CTA',
      parts: {
        greeting,
        hook: hookLine,
        bridge: bridgeLine,
        cta: ctaLine,
        signOff: signature
      }
    }
  };
}

// ─── Executive AI Message Builder (Anthropic API + Cached Resume) ────────────
async function aiStructuredMessage(apiKey, p, hooks, messageType, tone, settings = {}, model = DEFAULT_MODEL, customContext = '', maxChars = 300) {
  const resume = settings.resumeSummary || null;
  const isShortNote = maxChars <= 300;
  const senderContext = {
    name: settings.userName || '(not given)',
    bio: settings.userBio || '(not given)',
    resumeHeadline: resume?.headline || null,
    resumeSummary: resume?.summary || null,
    resumeSkills: resume?.skills || [],
    resumeHighlights: resume?.highlights || []
  };

  const prompt =
`You are an elite executive outreach copywriter (writing style: concise, peer-to-peer, high-signal, zero fluff).
Write a structured LinkedIn ${isShortNote ? 'Connection Request Note' : 'Direct Message'}.
Purpose: ${messageType} | Tone: ${tone} | Hard Character Limit: STRICTLY <= ${maxChars} characters (including newlines).

Recipient Profile:
${JSON.stringify({
  name: p.name,
  headline: p.headline,
  title: p.currentTitle,
  company: p.currentCompany,
  seniority: p.inferredSeniority || '',
  domainFocus: p.domainFocus || '',
  about: truncate(p.about, 400),
  recentPosts: p.recentPosts,
  skills: p.skills
})}

Selected Personalization Hooks: ${hooks.length ? hooks.join(' | ') : 'Use role/company focus'}
${customContext?.trim() ? `User's Specific Goal (weave in naturally): ${customContext.trim()}` : ''}
Sender Context: ${JSON.stringify(senderContext)}

Return ONLY valid JSON (no markdown fences) with this exact schema:
{
  "angle": "2-3 word label of the hook angle (e.g., Shared Stack, Recent Insight, Product Focus)",
  "greeting": "Hi ${p.firstName},",
  "hook": "1 sharp, natural observation about their specific work/post—NEVER copy-paste raw pipe-separated LinkedIn headlines",
  "bridge": "${isShortNote ? 'Optional ultra-crisp 1-clause credibility/goal tie-in (or empty string to stay concise)' : '1-2 sentences tying sender background/resume highlights to recipient domain'}",
  "cta": "1 specific, low-friction closing question or ask",
  "signOff": "Best, ${settings.userName || ''}"
}
Strict Copywriting Rules:
- Total assembled message MUST be <= ${maxChars} characters.
- BANNED phrases: "delve", "synergy", "thrilled to connect", "hope this finds you well", "impressed by your work as", "would love to connect and exchange ideas".
- Write like a sharp AI Product Engineer messaging a respected peer.`;

  const raw = await callClaude(apiKey, prompt, 500, model);
  const parsed = parseSafeJSON(raw);

  const greeting = String(parsed.greeting || `Hi ${p.firstName},`).trim();
  const hook = String(parsed.hook || '').trim();
  const bridge = String(parsed.bridge || '').trim();
  const cta = String(parsed.cta || '').trim();
  const signOff = String(parsed.signOff || `Best, ${settings.userName || ''}`).trim();

  const assembled = isShortNote
    ? `${greeting}\n\n${hook}${bridge ? ' ' + bridge : ''} ${cta}\n\n${signOff}`
    : `${greeting}\n\n${hook}${bridge ? '\n\n' + bridge : ''}\n\n${cta}\n\n${signOff}`;

  const finalMessage = smartTrimToLimit(assembled, maxChars);

  return {
    message: finalMessage,
    meta: {
      angle: String(parsed.angle || 'Domain Focus').trim(),
      channelLabel: isShortNote ? 'Connection Note' : 'Direct Message',
      structure: isShortNote ? 'Hook → Micro-CTA' : 'Hook → Credibility Bridge → CTA',
      parts: { greeting, hook, bridge, cta, signOff }
    }
  };
}

async function callClaude(apiKey, userContent, maxTokens, model = DEFAULT_MODEL) {
  const res = await fetch(ANTHROPIC_URL, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'x-api-key': apiKey,
      'anthropic-version': '2023-06-01',
      'anthropic-dangerous-direct-browser-access': 'true'
    },
    body: JSON.stringify({
      model,
      max_tokens: maxTokens,
      messages: [{ role: 'user', content: userContent }]
    })
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data?.error?.message || `API error (${res.status})`);
  return (data.content || []).map(c => c.text || '').join('');
}

// ─── Utils ────────────────────────────────────────────────────────────────────
function parseSafeJSON(raw) {
  const cleaned = String(raw || '').replace(/```json|```/gi, '').trim();
  const start = cleaned.indexOf('{');
  const end = cleaned.lastIndexOf('}');
  const slice = (start !== -1 && end !== -1) ? cleaned.slice(start, end + 1) : cleaned;
  return JSON.parse(slice);
}

function smartTrimToLimit(text, maxChars) {
  const clean = String(text || '').trim();
  if (clean.length <= maxChars) return clean;
  const cut = clean.slice(0, maxChars - 1);
  const lastBreak = Math.max(cut.lastIndexOf('. '), cut.lastIndexOf('\n'), cut.lastIndexOf(' '));
  return (lastBreak > maxChars * 0.6 ? cut.slice(0, lastBreak) : cut).trim() + '…';
}

function getApiKey() {
  return new Promise(resolve => {
    chrome.storage.local.get(['userApiKey'], r => resolve((r.userApiKey || '').trim()));
  });
}

function getStoredModel() {
  return new Promise(resolve => {
    chrome.storage.local.get(['claudeModel'], r => resolve((r.claudeModel || DEFAULT_MODEL).trim()));
  });
}

function truncate(s, n) {
  s = String(s || '').replace(/\s+/g, ' ').trim();
  return s.length > n ? s.slice(0, n - 1) + '…' : s;
}

function stringify(x) {
  return typeof x === 'string' ? x : (x?.school || x?.name || x?.title || Object.values(x || {}).join(', '));
}

function delay(ms) {
  return new Promise(r => setTimeout(r, ms));
}