'use strict';

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.action === 'scrapeProfile') {
    if (window !== window.top) return false;
    scrapeWithScroll().then(profile => {
      sendResponse({ success: true, data: profile });
    }).catch(err => {
      sendResponse({ success: false, error: err.message });
    });
    return true;
  }

  if (msg.action === 'insertIfOpen') {
    tryInsertIntoOpenComposer(msg.text, msg.channel)
      .then(status => sendResponse(status ? { success: true, status } : { success: false }))
      .catch(() => sendResponse({ success: false }));
    return true;
  }

  if (msg.action === 'insertMessage') {
    if (window !== window.top) return false;
    insertIntoLinkedIn(msg.text, msg.channel)
      .then(status => sendResponse({ success: true, status }))
      .catch(err => sendResponse({ success: false, error: err.message }));
    return true;
  }
});

async function scrapeWithScroll() {
  window.scrollTo(0, 800); await wait(500);
  window.scrollTo(0, 1600); await wait(500);
  window.scrollTo(0, 2400); await wait(600);
  window.scrollTo(0, 0); await wait(300);
  return scrapeProfile();
}

function wait(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

function scrapeProfile() {
  const clean = (str) => (str || '').replace(/\s+/g, ' ').trim();

  function getSection(heading) {
    return Array.from(document.querySelectorAll('section')).find(s =>
      s.querySelector('h2')?.innerText?.trim().toLowerCase().includes(heading.toLowerCase())
    ) || null;
  }

  function getTexts(section) {
    if (!section) return [];
    return Array.from(section.querySelectorAll('p, span'))
      .filter(el => el.children.length === 0)
      .map(el => clean(el.innerText))
      .filter(t => t.length > 2 && !/^[·•\s]+$/.test(t));
  }

  // ── NAME (Strips leading LinkedIn notification count like "(1) ") ──────────
  const rawH1 = clean(document.querySelector('h1')?.innerText);
  const rawTitleName = clean(document.title.split('|')[0]).replace(/^\(\d+\)\s*/, '');
  const name = (rawH1 && !/^\(\d+\)$/.test(rawH1)) ? rawH1 : rawTitleName;

  // ── HEADLINE ──────────────────────────────────────────────────────────────
  let headline = null;
  const allSections = Array.from(document.querySelectorAll('section'));
  for (const sec of allSections) {
    if (sec.querySelector('h1')) {
      const pTags = Array.from(sec.querySelectorAll('p, div.text-body-medium'))
        .filter(p => p.children.length === 0)
        .map(p => clean(p.innerText))
        .filter(t => t.length > 5 && t !== name);
      const headlineEl = pTags.find(t =>
        t.includes('|') || t.includes('@') || t.includes('·') ||
        /manager|engineer|analyst|developer|designer|founder|director|lead|specialist|consultant|intern|fellow|trainee|researcher/i.test(t)
      ) || pTags[0];
      if (headlineEl) { headline = headlineEl; break; }
    }
  }

  // ── LOCATION ──────────────────────────────────────────────────────────────
  let location = null;
  for (const sec of allSections) {
    if (sec.querySelector('h1')) {
      const pTags = Array.from(sec.querySelectorAll('p, span.text-body-small'))
        .filter(p => p.children.length === 0)
        .map(p => clean(p.innerText))
        .filter(t => t.length > 3);
      const locEl = pTags.find(t =>
        t.includes(',') && t.length < 60 && !t.includes('|') && !t.includes('@')
      );
      if (locEl) { location = locEl; break; }
    }
  }

  // ── ABOUT ─────────────────────────────────────────────────────────────────
  let about = null;
  const aboutSection = getSection('About');
  if (aboutSection) {
    const texts = getTexts(aboutSection);
    const longText = texts.find(t => t.length > 80 && !t.includes('Experience') && !t.includes('Skills'));
    if (longText) about = longText;
  }

  // ── EXPERIENCE ────────────────────────────────────────────────────────────
  const experienceEntries = [];
  const expSection = getSection('Experience');
  if (expSection) {
    const pTags = Array.from(expSection.querySelectorAll('p, span'))
      .filter(p => p.children.length === 0)
      .map(p => clean(p.innerText))
      .filter(t => t.length > 2 && t !== 'Experience');

    let i = 0;
    while (i < pTags.length) {
      const title = pTags[i];
      const company = pTags[i + 1] || null;
      const dur = pTags[i + 2] || null;

      if (/^\d{4}|present|jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec/i.test(title)) {
        i++; continue;
      }

      experienceEntries.push({
        title,
        company: company ? company.split('·')[0].trim() : null,
        duration: dur && /\d{4}|present|yr|mos|mo\b/i.test(dur) ? dur : null,
        isCurrent: experienceEntries.length === 0
      });

      i += /remote|onsite|on-site|hybrid|india|bengaluru|mumbai|delhi|hyderabad|pune|chennai|usa|uk|san francisco|new york|london/i.test(pTags[i + 3] || '')
        ? 4 : 3;
    }
  }

  const currentEntry = experienceEntries[0] || null;
  const currentTitle = currentEntry?.title || extractFromHeadline(headline, 'title');
  const currentCompany = currentEntry?.company || extractFromHeadline(headline, 'company');
  const pastCompanies = [...new Set(
    experienceEntries.slice(1).map(e => e.company).filter(Boolean)
  )];

  // ── SKILLS ────────────────────────────────────────────────────────────────
  const skills = [];
  const skillsSection = getSection('Skills');
  if (skillsSection) {
    const texts = getTexts(skillsSection);
    texts.filter(t =>
      t !== 'Skills' &&
      t.length < 60 &&
      t.length > 2 &&
      !/\d{4}|follower|connection|endorsement|endorse|show all|see all|dialog|window|escape/i.test(t)
    ).forEach(t => { if (!skills.includes(t)) skills.push(t); });
  }

  // ── EDUCATION ─────────────────────────────────────────────────────────────
  const educationEntries = [];
  const eduSection = getSection('Education');
  if (eduSection) {
    const pTags = Array.from(eduSection.querySelectorAll('p, span'))
      .filter(p => p.children.length === 0)
      .map(p => clean(p.innerText))
      .filter(t => t.length > 2 && t !== 'Education');
    for (let i = 0; i < pTags.length; i += 3) {
      if (pTags[i]) {
        educationEntries.push([pTags[i], pTags[i + 1]].filter(Boolean).join(' — '));
      }
    }
  }

  // ── RECENT POSTS ──────────────────────────────────────────────────────────
  const recentPosts = [];
  const activitySection = getSection('Activity');
  if (activitySection) {
    Array.from(activitySection.querySelectorAll('p, span'))
      .filter(el => el.children.length === 0)
      .map(el => clean(el.innerText))
      .filter(t =>
        t.length > 40 && t.length < 500 &&
        t !== headline &&
        !/dialog|window|escape|cancel|close|beginning|notifications|premium|people you may|you might/i.test(t)
      )
      .forEach(t => { if (!recentPosts.includes(t)) recentPosts.push(t); });
  }

  return {
    name,
    headline,
    currentTitle,
    currentCompany,
    location,
    about,
    recentPosts: recentPosts.slice(0, 3),
    experienceEntries: experienceEntries.slice(0, 5),
    pastCompanies: pastCompanies.slice(0, 4),
    educationEntries: educationEntries.slice(0, 3),
    skills: skills.slice(0, 10),
    profileUrl: window.location.href.split('?')[0],
    rawTitle: document.title
  };
}

function extractFromHeadline(headline, field) {
  if (!headline) return null;
  const atMatch = headline.match(/^(.+?)\s+at\s+(.+)$/i);
  if (atMatch) return field === 'title' ? atMatch[1].trim() : atMatch[2].trim();
  const pipeMatch = headline.match(/^(.+?)\s*[|·]\s*(.+)$/);
  if (pipeMatch) return field === 'title' ? pipeMatch[1].trim() : pipeMatch[2].trim();
  return null;
}

// ─── Shadow-DOM-Aware Query Helpers (Pierces LinkedIn #interop-outlet) ────────
function queryAllDeep(selector, root = document) {
  const results = Array.from(root.querySelectorAll(selector));
  const walk = (node) => {
    if (!node) return;
    if (node.shadowRoot) {
      results.push(...Array.from(node.shadowRoot.querySelectorAll(selector)));
      node.shadowRoot.querySelectorAll('*').forEach(walk);
    }
  };
  root.querySelectorAll('*').forEach(walk);
  return results;
}

function isVisible(el) {
  return Boolean(el && (el.offsetWidth || el.offsetHeight || el.getClientRects().length));
}

function findDeepButtonByText(labels) {
  const buttons = queryAllDeep('button, a[role="button"]');
  return buttons.find(btn => {
    const txt = (btn.innerText || btn.textContent || '').replace(/\s+/g, ' ').trim();
    const aria = (btn.getAttribute('aria-label') || '').replace(/\s+/g, ' ').trim();
    return labels.some(l =>
      txt.toLowerCase() === l.toLowerCase() ||
      aria.toLowerCase() === l.toLowerCase() ||
      new RegExp(`^${l}(\\b|\\s)`, 'i').test(txt)
    );
  }) || null;
}

function waitForDeepSelector(selector, timeoutMs = 4500) {
  return new Promise(resolve => {
    const check = () => queryAllDeep(selector)[0] || null;
    const found = check();
    if (found) return resolve(found);

    const timer = setInterval(() => {
      const el = check();
      if (el) {
        clearInterval(timer);
        resolve(el);
      }
    }, 150);

    setTimeout(() => {
      clearInterval(timer);
      resolve(null);
    }, timeoutMs);
  });
}

function waitForDeepButton(labels, timeoutMs = 4500) {
  return new Promise(resolve => {
    const found = findDeepButtonByText(labels);
    if (found) return resolve(found);

    const timer = setInterval(() => {
      const btn = findDeepButtonByText(labels);
      if (btn) {
        clearInterval(timer);
        resolve(btn);
      }
    }, 150);

    setTimeout(() => {
      clearInterval(timer);
      resolve(null);
    }, timeoutMs);
  });
}

// ─── Already-Open Composer Injection (Runs across ALL frames) ─────────────────
async function tryInsertIntoOpenComposer(text, channel = 'connect') {
  const noteSelector = 'textarea[name="message"], #custom-message, textarea[id*="custom-message"], textarea[aria-label*="note" i], textarea';
  const msgSelector = 'div.msg-form__contenteditable[contenteditable="true"], div[role="textbox"][contenteditable="true"]';

  const noteBox = queryAllDeep(noteSelector).find(el => isVisible(el));
  if (noteBox) {
    setNativeValue(noteBox, text);
    return 'Inserted into open Connection Note box!';
  }

  const addNoteBtn = findDeepButtonByText(['Add a note']);
  if (addNoteBtn && isVisible(addNoteBtn)) {
    addNoteBtn.click();
    const openedBox = await waitForDeepSelector(noteSelector, 3500);
    if (openedBox) {
      setNativeValue(openedBox, text);
      return 'Clicked Add a note & inserted message!';
    }
  }

  if (channel === 'dm') {
    const msgBox = queryAllDeep(msgSelector).find(el => isVisible(el));
    if (msgBox) {
      setContentEditableText(msgBox, text);
      return 'Inserted into open LinkedIn Message box!';
    }
  }

  return null;
}

// ─── LinkedIn DOM Composer Injection (Top frame trigger) ──────────────────────
async function insertIntoLinkedIn(text, channel = 'connect') {
  const openStatus = await tryInsertIntoOpenComposer(text, channel);
  if (openStatus) return openStatus;

  const noteSelector = 'textarea[name="message"], #custom-message, textarea[id*="custom-message"], textarea[aria-label*="note" i]';
  const msgSelector = 'div.msg-form__contenteditable[contenteditable="true"], div[role="textbox"][contenteditable="true"]';
  const main = document.querySelector('main') || document.body;

  if (channel === 'connect') {
    const opened = await tryOpenConnectNoteModal(main, noteSelector);
    if (!opened) {
      throw new Error('Could not find Connect button (may already be connected or Pending). Try DM (600) mode.');
    }
    const noteBox = await waitForDeepSelector(noteSelector, 4500);
    if (!noteBox) throw new Error('Connection modal opened, but note textarea was not found.');
    setNativeValue(noteBox, text);
    return 'Opened Connect modal & inserted note!';
  } else {
    const msgBtn = findMessageTrigger(main);
    if (!msgBtn) {
      throw new Error('Message button unavailable (may require Premium/InMail). Switch to Note (300) mode.');
    }
    msgBtn.click();
    const msgBox = await waitForDeepSelector(msgSelector, 4500);
    if (!msgBox) throw new Error('Message drawer opened, but text box was not found.');
    setContentEditableText(msgBox, text);
    return 'Opened Message drawer & inserted draft!';
  }
}

async function tryOpenConnectNoteModal(root, noteSelector) {
  const topCard = Array.from(root.querySelectorAll('section')).find(s => s.querySelector('h1')) || root;

  let connectBtn = findConnectTrigger(topCard);

  if (!connectBtn) {
    const moreBtn = findMoreTrigger(topCard);
    if (moreBtn) {
      moreBtn.click();
      await wait(600);
      connectBtn = findDropdownConnectTrigger();
    }
  }

  if (!connectBtn) return false;
  connectBtn.click();

  const addNoteBtn = await waitForDeepButton(['Add a note'], 4500);
  if (addNoteBtn) {
    addNoteBtn.click();
    await wait(300);
    return true;
  }
  return Boolean(queryAllDeep(noteSelector)[0]);
}

function findConnectTrigger(container) {
  const candidates = queryAllDeep('button, a[role="button"], a[href*="/preload/custom-invite"]', container);
  return candidates.find(el => {
    if (!isVisible(el)) return false;
    const txt = (el.innerText || el.textContent || '').replace(/\s+/g, ' ').trim();
    const aria = (el.getAttribute('aria-label') || '').replace(/\s+/g, ' ').trim();
    return /^connect$/i.test(txt) || /^invite\s+.+\s+to connect/i.test(aria);
  }) || null;
}

function findMoreTrigger(container) {
  const buttons = queryAllDeep('button', container);
  return buttons.find(btn => {
    if (!isVisible(btn)) return false;
    const txt = (btn.innerText || btn.textContent || '').replace(/\s+/g, ' ').trim();
    const aria = (btn.getAttribute('aria-label') || '').replace(/\s+/g, ' ').trim();
    const id = (btn.id || '').toLowerCase();
    return (
      /^more(\s+actions|\s+options)?$/i.test(txt) ||
      /^more(\s+actions|\s+options)?$/i.test(aria) ||
      id.includes('profile-overflow-action')
    );
  }) || null;
}

function findDropdownConnectTrigger() {
  const items = queryAllDeep('[role="menuitem"], [role="button"], div.artdeco-dropdown__item, li, a, button');
  return items.find(el => {
    if (!isVisible(el)) return false;
    const txt = (el.innerText || el.textContent || '').replace(/\s+/g, ' ').trim();
    const aria = (el.getAttribute('aria-label') || '').replace(/\s+/g, ' ').trim();
    return /^connect$/i.test(txt) || /^invite\s+.+\s+to connect/i.test(aria);
  }) || null;
}

function findMessageTrigger(container) {
  const topCard = Array.from(container.querySelectorAll('section')).find(s => s.querySelector('h1')) || container;
  const candidates = queryAllDeep('button, a[role="button"]', topCard);
  return candidates.find(el => {
    if (!isVisible(el)) return false;
    const txt = (el.innerText || el.textContent || '').replace(/\s+/g, ' ').trim();
    const aria = (el.getAttribute('aria-label') || '').replace(/\s+/g, ' ').trim();
    return /^message$/i.test(txt) || /^message\s+/i.test(aria);
  }) || null;
}

// ─── React-Safe Text Injection ────────────────────────────────────────────────
function setNativeValue(textarea, value) {
  textarea.focus();
  const setter = Object.getOwnPropertyDescriptor(window.HTMLTextAreaElement.prototype, 'value')?.set;
  if (setter) setter.call(textarea, value);
  else textarea.value = value;
  textarea.dispatchEvent(new Event('input', { bubbles: true }));
  textarea.dispatchEvent(new Event('change', { bubbles: true }));
}

function setContentEditableText(el, value) {
  el.focus();
  document.execCommand('selectAll', false, null);
  document.execCommand('insertText', false, value);
  el.dispatchEvent(new InputEvent('input', { bubbles: true, data: value, inputType: 'insertText' }));
}