'use strict';

// ─── State ────────────────────────────────────────────────────────────────────
let currentProfile = null;
let isGenerating = false;
let currentMode = 'simple';
let deepProfileJSON = null;
let deepEnrichmentJSON = null;
let isEnriching = false;
let pendingResume = null;

// ─── Boot ─────────────────────────────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', async () => {
  initTabs();
  initModeToggle();
  wireSettingsEvents();
  wireCurrentEvents();
  wireRecentEvents();
  await checkCurrentPage();
  await loadSettings();
  await renderRecentContacts();
  await checkLicenseStatus();
});

// ─── License key status in header ────────────────────────────────────────────
async function checkLicenseStatus() {
  const s = await loadStoredSettings();
  const key = (s.userApiKey || '').trim();
  const el = document.getElementById('key-status');
  el.textContent = key ? '● AI Mode' : '● Free Mode';
  el.className = 'key-status active';
}

// ─── Tabs ─────────────────────────────────────────────────────────────────────
function initTabs() {
  document.querySelectorAll('.tab-btn').forEach(btn => {
    btn.addEventListener('click', () => switchTab(btn.dataset.tab));
  });
}

function switchTab(name) {
  document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
  document.querySelectorAll('.tab-content').forEach(c => c.classList.remove('active'));
  document.querySelector(`.tab-btn[data-tab="${name}"]`).classList.add('active');
  document.getElementById(`tab-${name}`).classList.add('active');
  if (name === 'recent') renderRecentContacts();
}

// ─── Mode toggle ──────────────────────────────────────────────────────────────
function initModeToggle() {
  document.getElementById('mode-simple').addEventListener('click', () => setMode('simple'));
  document.getElementById('mode-deep').addEventListener('click', () => setMode('deep'));
}

function setMode(mode) {
  currentMode = mode;
  document.getElementById('mode-simple').classList.toggle('active', mode === 'simple');
  document.getElementById('mode-deep').classList.toggle('active', mode === 'deep');
  document.getElementById('simple-mode-ui').classList.toggle('hidden', mode === 'deep');
  document.getElementById('deep-mode-ui').classList.toggle('hidden', mode === 'simple');
  hideMessage();
  clearCurrentStatus();
}

// ─── Page check ───────────────────────────────────────────────────────────────
async function checkCurrentPage() {
  const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
  const tab = tabs[0];
  const onProfile = tab && tab.url && /linkedin\.com\/in\/[^/?#]+/.test(tab.url);
  document.getElementById('scrape-btn').disabled = !onProfile;
  document.getElementById('enrich-btn').disabled = !onProfile;
  if (!onProfile) {
    document.getElementById('page-warning').classList.remove('hidden');
  } else {
    document.getElementById('page-warning').classList.add('hidden');
  }
  return onProfile;
}

// ─── Wire events ──────────────────────────────────────────────────────────────
function wireCurrentEvents() {
  document.getElementById('scrape-btn').addEventListener('click', handleScrapeAndGenerate);
  document.getElementById('enrich-btn').addEventListener('click', handleEnrich);
  document.getElementById('deep-generate-btn').addEventListener('click', handleDeepGenerate);
  document.getElementById('regenerate-btn').addEventListener('click', handleRegenerate);
  document.getElementById('copy-btn').addEventListener('click', handleCopy);
  document.getElementById('shorten-btn').addEventListener('click', handleShorten);
  document.getElementById('insert-linkedin-btn').addEventListener('click', handleInsertLinkedIn);
  document.getElementById('channel-mode').addEventListener('change', updateCharCount);
  document.getElementById('generated-message').addEventListener('input', updateCharCount);
}

function wireSettingsEvents() {
  document.getElementById('save-settings-btn').addEventListener('click', handleSaveSettings);
  document.getElementById('validate-btn').addEventListener('click', handleValidateKey);
  document.getElementById('api-key').addEventListener('keydown', e => {
    if (e.key === 'Enter') handleValidateKey();
  });

  // Resume upload
  const dropArea = document.getElementById('file-upload-area');
  dropArea.addEventListener('click', () => document.getElementById('resume-upload').click());
  dropArea.addEventListener('dragover', (e) => { e.preventDefault(); dropArea.classList.add('drag-over'); });
  dropArea.addEventListener('dragleave', () => dropArea.classList.remove('drag-over'));
  dropArea.addEventListener('drop', (e) => {
    e.preventDefault();
    dropArea.classList.remove('drag-over');
    const file = e.dataTransfer.files[0];
    if (file) processResumeFile(file);
  });
  document.getElementById('resume-upload').addEventListener('change', (e) => {
    const file = e.target.files[0];
    if (file) processResumeFile(file);
  });
}

function wireRecentEvents() {
  document.getElementById('clear-recent-btn').addEventListener('click', async () => {
    await Cache.clearContacts();
    renderRecentContacts();
  });
}

// ─── Simple Mode ──────────────────────────────────────────────────────────────
async function handleScrapeAndGenerate() {
  if (isGenerating) return;

  isGenerating = true;
  hideMessage();
  setButtonLoading('scrape-btn', 'btn-label', 'btn-spinner', true, 'Scraping profile…');
  clearCurrentStatus();

  try {
    const profile = await sendToBackground({ action: 'scrapeProfile' });
    currentProfile = profile;
    renderProfileCard(profile);
    setButtonLoading('scrape-btn', 'btn-label', 'btn-spinner', true, 'Generating message…');

    const result = await callQuickGenerate(profile);
    renderMessage(result.generatedMessage, result.structuredMeta);

    await Cache.addContact({
      profileUrl: profile.profileUrl || '',
      name: profile.name || 'Unknown',
      headline: profile.headline || '',
      company: profile.currentCompany || '',
      message: result.generatedMessage,
      timestamp: Date.now()
    });

    showCurrentStatus('Structured message ready.', 'success');
  } catch (err) {
    showCurrentStatus(err.message, 'error');
  } finally {
    isGenerating = false;
    setButtonLoading('scrape-btn', 'btn-label', 'btn-spinner', false, 'Scrape &amp; Generate');
  }
}

async function callQuickGenerate(profile) {
  const settings = await loadStoredSettings();
  const messageType = document.getElementById('message-type').value;
  const tone = document.getElementById('tone').value;
  const customContext = document.getElementById('custom-context').value.trim();
  const maxChars = getMaxChars();

  return new Promise((resolve, reject) => {
    chrome.runtime.sendMessage(
      {
        action: 'generateMessage',
        data: { profileData: profile, settings, messageType, tone, customContext, maxChars }
      },
      (response) => {
        if (chrome.runtime.lastError) { reject(new Error(chrome.runtime.lastError.message)); return; }
        if (!response || !response.success) { reject(new Error(response?.error || 'Generation failed.')); return; }
        resolve({
          generatedMessage: response.generatedMessage,
          structuredMeta: response.structuredMeta || null
        });
      }
    );
  });
}

async function handleRegenerate() {
  if (isGenerating) return;
  if (currentMode === 'deep') { handleDeepGenerate(); return; }
  if (!currentProfile) return;

  isGenerating = true;
  setButtonLoading('scrape-btn', 'btn-label', 'btn-spinner', true, 'Regenerating…');

  try {
    const result = await callQuickGenerate(currentProfile);
    renderMessage(result.generatedMessage, result.structuredMeta);
    showCurrentStatus('Regenerated!', 'success');
  } catch (err) {
    showCurrentStatus(err.message, 'error');
  } finally {
    isGenerating = false;
    setButtonLoading('scrape-btn', 'btn-label', 'btn-spinner', false, 'Scrape &amp; Generate');
  }
}

// ─── Deep Mode ────────────────────────────────────────────────────────────────
async function handleEnrich() {
  if (isEnriching) return;

  deepProfileJSON = null;
  deepEnrichmentJSON = null;
  resetLayerStatuses();
  document.getElementById('hooks-panel').classList.add('hidden');
  document.getElementById('deep-generate-btn').disabled = true;
  hideMessage();
  clearCurrentStatus();

  isEnriching = true;
  setButtonLoading('enrich-btn', 'enrich-label', 'enrich-spinner', true, 'Scraping profile…');
  setLayerStatus(1, 'running', 'Scraping…');

  let rawProfileData;
  try {
    rawProfileData = await sendToBackground({ action: 'scrapeProfile' });
  } catch (err) {
    setLayerStatus(1, 'error', 'Failed');
    showCurrentStatus('Could not scrape. Are you on a LinkedIn profile page?', 'error');
    isEnriching = false;
    setButtonLoading('enrich-btn', 'enrich-label', 'enrich-spinner', false, 'Scrape + Enrich (L1 + L2)');
    return;
  }

  currentProfile = rawProfileData;
  renderProfileCard(rawProfileData);
  setLayerStatus(1, 'running', 'Parsing…');
  setLayerStatus(2, 'running', 'Extracting…');
  setButtonLoading('enrich-btn', 'enrich-label', 'enrich-spinner', true, 'Running AI layers…');
  showCurrentStatus('Enriching profile & matching resume fit…');

  chrome.runtime.sendMessage({ type: 'RUN_ENRICH', payload: { rawProfileData } }, (response) => {
    isEnriching = false;
    setButtonLoading('enrich-btn', 'enrich-label', 'enrich-spinner', false, 'Scrape + Enrich (L1 + L2)');

    if (chrome.runtime.lastError || !response) {
      setLayerStatus(1, 'error', 'Error');
      setLayerStatus(2, 'error', 'Error');
      showCurrentStatus('Pipeline error. Check your connection.', 'error');
      return;
    }

    if (response.status === 'error') {
      setLayerStatus(1, 'error', 'Error');
      setLayerStatus(2, 'error', 'Error');
      showCurrentStatus(response.error, 'error');
      return;
    }

    setLayerStatus(1, 'done', 'Done');
    setLayerStatus(2, 'done', 'Done');
    deepProfileJSON = response.profileJSON;
    deepEnrichmentJSON = response.enrichmentJSON;
    renderProfileCard({
      name: deepProfileJSON.name,
      headline: deepProfileJSON.headline,
      currentCompany: deepProfileJSON.currentCompany
    });
    renderHooks(deepEnrichmentJSON);
    setLayerStatus(3, '', 'Ready');
    document.getElementById('deep-generate-btn').disabled = false;
    showCurrentStatus('Hooks & resume fit ready — click Generate Message.', 'success');
  });
}

async function handleDeepGenerate() {
  if (isGenerating || !deepProfileJSON || !deepEnrichmentJSON) return;

  const selectedHooks = getSelectedHooks();
  const customContext = document.getElementById('custom-context').value.trim();
  const maxChars = getMaxChars();

  isGenerating = true;
  setButtonLoading('deep-generate-btn', 'deep-gen-label', 'deep-gen-spinner', true, 'Writing message…');
  setLayerStatus(3, 'running', 'Writing…');
  showCurrentStatus('Layer 3: synthesizing structured outreach…');
  hideMessage();

  const messageType = document.getElementById('message-type').value;
  const tone = document.getElementById('tone').value;

  chrome.runtime.sendMessage(
    {
      type: 'RUN_GENERATE',
      payload: {
        profileJSON: deepProfileJSON,
        selectedHooks,
        customContext,
        messageType,
        tone,
        maxChars
      }
    },
    async (response) => {
      isGenerating = false;
      setButtonLoading('deep-generate-btn', 'deep-gen-label', 'deep-gen-spinner', false, 'Generate Message (L3)');

      if (chrome.runtime.lastError || !response) {
        setLayerStatus(3, 'error', 'Error');
        showCurrentStatus('Generation failed.', 'error');
        return;
      }

      if (response.status === 'error') {
        setLayerStatus(3, 'error', 'Error');
        showCurrentStatus(response.error, 'error');
        return;
      }

      setLayerStatus(3, 'done', 'Done');
      renderMessage(response.generatedMessage, response.structuredMeta);
      showCurrentStatus('Structured message synthesized from selected hooks.', 'success');

      await Cache.addContact({
        profileUrl: deepProfileJSON.profileUrl || '',
        name: deepProfileJSON.name || 'Unknown',
        headline: deepProfileJSON.headline || '',
        company: deepProfileJSON.currentCompany || '',
        message: response.generatedMessage,
        timestamp: Date.now()
      });
    }
  );
}

// ─── Interactive Hook Checkboxes + Profile Fit & Talking Points ───────────────
function renderHooks(enrichmentJSON) {
  const panel = document.getElementById('hooks-panel');
  const list = document.getElementById('hooks-list');
  const insightBox = document.getElementById('l1-insight-box');
  list.innerHTML = '';

  if (deepProfileJSON?.domainFocus || deepProfileJSON?.inferredSeniority) {
    const parts = [
      deepProfileJSON.inferredSeniority ? `<strong>${esc(deepProfileJSON.inferredSeniority)}</strong>` : '',
      deepProfileJSON.domainFocus ? esc(deepProfileJSON.domainFocus) : ''
    ].filter(Boolean);
    insightBox.innerHTML = `L1 Focus: ${parts.join(' · ')}`;
    insightBox.classList.remove('hidden');
  } else {
    insightBox.classList.add('hidden');
  }

  const hooks = enrichmentJSON.topHooks || [];
  if (!hooks.length) return;

  hooks.slice(0, 4).forEach((hook, idx) => {
    const hookObj = typeof hook === 'string'
      ? { category: 'Profile', strength: 'High', text: hook }
      : hook;

    const label = document.createElement('label');
    label.className = 'hook-item';
    label.style.cssText = 'display:flex; align-items:flex-start; gap:8px; cursor:pointer; user-select:none;';

    const cb = document.createElement('input');
    cb.type = 'checkbox';
    cb.className = 'hook-checkbox';
    cb.checked = idx < 2;
    cb.dataset.hookText = hookObj.text;
    cb.style.marginTop = '3px';
    cb.addEventListener('change', updateHookSelectionCount);

    const textWrap = document.createElement('div');
    textWrap.style.flex = '1';
    textWrap.innerHTML = `
      <div style="font-size:10px; font-weight:600; text-transform:uppercase; color:var(--accent); margin-bottom:2px;">
        ${esc(hookObj.category)} · ${esc(hookObj.strength)}
      </div>
      <div>${esc(hookObj.text)}</div>
    `;

    label.appendChild(cb);
    label.appendChild(textWrap);
    list.appendChild(label);
  });

  // Render Profile Fit & Reply Talking Points Card (connects PDF resume to prospect)
  const fit = enrichmentJSON.profileFit;
  if (fit && (fit.talkingPoints?.length || fit.matchedSkills?.length)) {
    const fitCard = document.createElement('div');
    fitCard.style.cssText = 'margin-top:8px; padding:8px 10px; background:var(--success-bg); border:1px solid #A7F3D0; border-radius:6px; font-size:11.5px; color:var(--text);';

    const badgesHtml = (fit.matchedSkills || []).length
      ? `<div style="display:flex; flex-wrap:wrap; gap:4px; margin:5px 0;">
          ${fit.matchedSkills.map(s => `<span style="background:#D1FAE5; color:var(--success); font-size:10px; font-weight:600; padding:1px 6px; border-radius:10px;">✓ ${esc(s)}</span>`).join('')}
        </div>`
      : '';

    const pointsHtml = (fit.talkingPoints || []).map(tp =>
      `<div style="margin-top:3px; padding-left:10px; position:relative; line-height:1.4;">
        <span style="position:absolute; left:0; color:var(--success); font-weight:700;">•</span>${esc(tp)}
      </div>`
    ).join('');

    fitCard.innerHTML = `
      <div style="font-size:10px; font-weight:700; text-transform:uppercase; letter-spacing:0.04em; color:var(--success);">
        🎯 Profile Fit · ${esc(fit.fitLabel || 'Resume Match')}
      </div>
      ${badgesHtml}
      ${pointsHtml}
    `;
    list.appendChild(fitCard);
  }

  updateHookSelectionCount();
  panel.classList.remove('hidden');
}

function getSelectedHooks() {
  return Array.from(document.querySelectorAll('.hook-checkbox:checked'))
    .map(cb => cb.dataset.hookText)
    .filter(Boolean);
}

function updateHookSelectionCount() {
  const checked = document.querySelectorAll('.hook-checkbox:checked').length;
  const total = document.querySelectorAll('.hook-checkbox').length;
  const badge = document.getElementById('hooks-selected-count');
  if (badge) badge.textContent = `${checked}/${total} selected`;
}

// ─── Channel Limits, Shorten & LinkedIn Insert (Multi-Frame + Shadow DOM) ─────
function getMaxChars() {
  return document.getElementById('channel-mode')?.value === 'dm' ? 600 : 300;
}

function updateCharCount() {
  const len = document.getElementById('generated-message').value.length;
  const max = getMaxChars();
  const countEl = document.getElementById('char-count');
  const shortenBtn = document.getElementById('shorten-btn');

  countEl.textContent = `${len} / ${max}`;
  if (len > max) {
    countEl.style.color = 'var(--error)';
    countEl.style.fontWeight = '700';
    shortenBtn.classList.remove('hidden');
  } else if (len >= max * 0.9) {
    countEl.style.color = 'var(--warning)';
    countEl.style.fontWeight = '600';
    shortenBtn.classList.add('hidden');
  } else {
    countEl.style.color = 'var(--text-2)';
    countEl.style.fontWeight = '500';
    shortenBtn.classList.add('hidden');
  }
}

async function handleShorten() {
  const ta = document.getElementById('generated-message');
  const text = ta.value.trim();
  const maxChars = getMaxChars();
  const tone = document.getElementById('tone').value;
  if (!text || text.length <= maxChars) return;

  const btn = document.getElementById('shorten-btn');
  btn.textContent = 'Shortening…';
  btn.disabled = true;

  chrome.runtime.sendMessage(
    { type: 'SHORTEN_MESSAGE', payload: { text, maxChars, tone } },
    (res) => {
      btn.textContent = '✂ Shorten to fit';
      btn.disabled = false;
      if (res?.success && res.shortenedMessage) {
        renderMessage(res.shortenedMessage);
        showCurrentStatus(`Shortened to ${res.shortenedMessage.length}/${maxChars} chars.`, 'success');
      } else {
        showCurrentStatus(res?.error || 'Could not shorten message.', 'error');
      }
    }
  );
}

async function handleInsertLinkedIn() {
  const text = document.getElementById('generated-message').value.trim();
  const channel = document.getElementById('channel-mode').value;
  if (!text) return;

  const btn = document.getElementById('insert-linkedin-btn');
  btn.disabled = true;
  btn.textContent = 'Inserting…';

  try {
    const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
    const tab = tabs[0];
    if (!tab?.id || !tab.url?.includes('linkedin.com')) {
      throw new Error('Open a LinkedIn profile tab first.');
    }

    const runAcrossFrames = async (actionType) => {
      const results = await chrome.scripting.executeScript({
        target: { tabId: tab.id, allFrames: true },
        func: (msgText, msgChannel, mode) => {
          const queryAllDeep = (selector, root = document) => {
            const out = Array.from(root.querySelectorAll(selector));
            const walk = (n) => {
              if (n?.shadowRoot) {
                out.push(...Array.from(n.shadowRoot.querySelectorAll(selector)));
                n.shadowRoot.querySelectorAll('*').forEach(walk);
              }
            };
            root.querySelectorAll('*').forEach(walk);
            return out;
          };

          const setNative = (el, val) => {
            el.focus();
            const setter = Object.getOwnPropertyDescriptor(window.HTMLTextAreaElement.prototype, 'value')?.set;
            if (setter) setter.call(el, val);
            else el.value = val;
            el.dispatchEvent(new Event('input', { bubbles: true }));
            el.dispatchEvent(new Event('change', { bubbles: true }));
          };

          const noteSel = 'textarea[name="message"], #custom-message, textarea[id*="custom-message"], textarea[aria-label*="note" i], textarea';
          const msgSel = 'div.msg-form__contenteditable[contenteditable="true"], div[role="textbox"][contenteditable="true"]';

          // Step A: Fill open note textarea
          const openNote = queryAllDeep(noteSel).find(el =>
            !el.disabled && el.id !== 'g-recaptcha-response' && el.getAttribute('aria-hidden') !== 'true'
          );
          if (openNote) {
            setNative(openNote, msgText);
            return { state: 'inserted', status: 'Inserted into Connection Note box!' };
          }

          // Step B: Click "Add a note" button if dialog is open
          const allBtns = queryAllDeep('button, a[role="button"], [role="menuitem"]');
          const addBtn = allBtns.find(b => {
            const t = (b.textContent || '').replace(/\s+/g, ' ').trim();
            const a = (b.getAttribute('aria-label') || '').replace(/\s+/g, ' ').trim();
            return /^add a note$/i.test(t) || /^add a note/i.test(a);
          });
          if (addBtn) {
            addBtn.click();
            return { state: 'clicked_add_note' };
          }

          // Step C: Fill open DM box
          if (msgChannel === 'dm') {
            const openMsg = queryAllDeep(msgSel).find(el => el.getAttribute('aria-hidden') !== 'true');
            if (openMsg) {
              openMsg.focus();
              document.execCommand('selectAll', false, null);
              document.execCommand('insertText', false, msgText);
              openMsg.dispatchEvent(new InputEvent('input', { bubbles: true, data: msgText, inputType: 'insertText' }));
              return { state: 'inserted', status: 'Inserted into LinkedIn Message box!' };
            }
          }

          // Step D: Initial trigger pass — click Connect / More->Connect or Message
          if (mode === 'trigger') {
            if (msgChannel === 'connect') {
              const directConnect = allBtns.find(b => {
                const t = (b.textContent || '').replace(/\s+/g, ' ').trim();
                const a = (b.getAttribute('aria-label') || '').replace(/\s+/g, ' ').trim();
                return /^connect$/i.test(t) || /^invite\s+.+\s+to connect/i.test(a);
              });
              if (directConnect) {
                directConnect.click();
                return { state: 'clicked_connect' };
              }
              const moreBtn = allBtns.find(b => {
                const t = (b.textContent || '').replace(/\s+/g, ' ').trim();
                const a = (b.getAttribute('aria-label') || '').replace(/\s+/g, ' ').trim();
                return /^more(\s+actions)?$/i.test(t) || /^more(\s+actions)?$/i.test(a);
              });
              if (moreBtn) {
                moreBtn.click();
                return { state: 'clicked_more' };
              }
            } else {
              const msgBtn = allBtns.find(b => {
                const t = (b.textContent || '').replace(/\s+/g, ' ').trim();
                const a = (b.getAttribute('aria-label') || '').replace(/\s+/g, ' ').trim();
                return /^message$/i.test(t) || /^message\s+/i.test(a);
              });
              if (msgBtn) {
                msgBtn.click();
                return { state: 'clicked_message' };
              }
            }
          }

          return { state: 'none' };
        },
        args: [text, channel, actionType]
      });
      return (results || []).map(r => r?.result).filter(Boolean);
    };

    // Pass 1: Check open boxes/modals OR click Connect / More / Message
    let states = await runAcrossFrames('trigger');
    let done = states.find(s => s.state === 'inserted');
    if (done) {
      showCurrentStatus(done.status, 'success');
      return;
    }

    // If "More" dropdown was opened, wait 500ms and click Connect inside the dropdown
    if (states.some(s => s.state === 'clicked_more')) {
      await new Promise(r => setTimeout(r, 500));
      states = await runAcrossFrames('trigger');
    }

    // Pass 2: Poll all frames for up to 5 seconds for "Add a note" -> textarea
    for (let attempt = 0; attempt < 25; attempt++) {
      await new Promise(r => setTimeout(r, 200));
      const pollStates = await runAcrossFrames('poll');
      const inserted = pollStates.find(s => s.state === 'inserted');
      if (inserted) {
        showCurrentStatus(inserted.status, 'success');
        return;
      }
    }

    throw new Error('Could not find Connect / Add a note box (may already be connected or Pending). Try DM (600) mode.');
  } catch (err) {
    showCurrentStatus(err.message, 'error');
  } finally {
    btn.disabled = false;
    btn.textContent = 'Insert into LinkedIn';
  }
}

// ─── Settings ─────────────────────────────────────────────────────────────────
async function loadSettings() {
  const s = await loadStoredSettings();
  if (s.userApiKey) document.getElementById('api-key').value = s.userApiKey;
  if (s.claudeModel) document.getElementById('claude-model').value = s.claudeModel;
  if (s.userName) document.getElementById('user-name').value = s.userName;
  if (s.userBio) document.getElementById('user-bio').value = s.userBio;
  if (s.resumeFileName) {
    document.getElementById('file-label').textContent = s.resumeFileName;
    document.getElementById('file-upload-area').classList.add('has-file');
    const statusEl = document.getElementById('resume-status');
    statusEl.textContent = s.resumeSummary
      ? `${s.resumeFileName} parsed & cached ✓`
      : `${s.resumeFileName} saved ✓`;
    statusEl.className = 'resume-status success';
    statusEl.classList.remove('hidden');
  }
  if (s.resumeSummary) renderResumeSummary(s.resumeSummary);
}

async function handleSaveSettings() {
  const saveBtn = document.getElementById('save-settings-btn');
  const userApiKey = document.getElementById('api-key').value.trim();
  const claudeModel = document.getElementById('claude-model').value;
  const userName = document.getElementById('user-name').value.trim();
  const userBio = document.getElementById('user-bio').value.trim();

  const existing = await loadStoredSettings();
  const savePayload = { userApiKey, claudeModel, userName, userBio };

  let resumeToParse = null;
  if (pendingResume) {
    savePayload.resumeBase64 = pendingResume.base64;
    savePayload.resumeFileName = pendingResume.fileName;
    resumeToParse = { resumeBase64: pendingResume.base64, resumeFileName: pendingResume.fileName };
    pendingResume = null;
  } else if (userApiKey && existing.resumeBase64 && !existing.resumeSummary) {
    resumeToParse = { resumeBase64: existing.resumeBase64, resumeFileName: existing.resumeFileName };
  }

  await new Promise(resolve => chrome.storage.local.set(savePayload, resolve));
  await checkLicenseStatus();

  if (resumeToParse) {
    saveBtn.disabled = true;
    saveBtn.textContent = 'Parsing Resume PDF…';
    const statusEl = document.getElementById('resume-status');
    statusEl.textContent = 'Extracting skills & highlights with Claude…';
    statusEl.className = 'resume-status pending';
    statusEl.classList.remove('hidden');

    const parseRes = await new Promise(resolve => {
      chrome.runtime.sendMessage({ type: 'PARSE_RESUME', payload: resumeToParse }, resolve);
    });

    saveBtn.disabled = false;
    saveBtn.textContent = 'Save Settings';

    if (parseRes?.success && parseRes.cached && parseRes.resumeSummary) {
      statusEl.textContent = `${resumeToParse.resumeFileName} parsed & cached ✓`;
      statusEl.className = 'resume-status success';
      renderResumeSummary(parseRes.resumeSummary);
      showSettingsStatus('Settings & resume cached!', 'success');
    } else if (parseRes?.success) {
      statusEl.textContent = parseRes.reason || 'Resume saved ✓';
      statusEl.className = 'resume-status success';
      showSettingsStatus('Settings saved!', 'success');
    } else {
      statusEl.textContent = `Resume saved, but parse failed: ${parseRes?.error || 'Unknown error'}`;
      statusEl.className = 'resume-status error';
      showSettingsStatus('Settings saved (resume parse failed).', 'error');
    }
  } else {
    showSettingsStatus('Settings saved!', 'success');
  }
}

function renderResumeSummary(rs) {
  const box = document.getElementById('resume-summary-preview');
  if (!rs || (!rs.headline && !rs.skills?.length)) {
    box.classList.add('hidden');
    return;
  }
  const skillsText = rs.skills?.length ? `Skills: ${rs.skills.slice(0, 6).join(', ')}` : '';
  box.innerHTML = `
    <div class="hooks-label">📄 Cached Resume Context</div>
    <div class="hook-item"><strong>${esc(rs.headline)}</strong></div>
    ${rs.summary ? `<div class="hook-item">${esc(rs.summary)}</div>` : ''}
    ${skillsText ? `<div class="hook-item">${esc(skillsText)}</div>` : ''}
  `;
  box.classList.remove('hidden');
}

async function handleValidateKey() {
  const apiKey = document.getElementById('api-key').value.trim();
  const model = document.getElementById('claude-model').value;
  if (!apiKey) return;

  const btn = document.getElementById('validate-btn');
  btn.textContent = '…';
  btn.disabled = true;

  const result = await new Promise(resolve => {
    chrome.runtime.sendMessage({ type: 'TEST_API_KEY', payload: { apiKey, model } }, resolve);
  });

  btn.textContent = 'Test';
  btn.disabled = false;

  const el = document.getElementById('key-validation-status');
  el.classList.remove('hidden');

  if (result && result.valid) {
    el.textContent = `✓ Key works (${model}) — AI Mode on`;
    el.className = 'key-validation-status valid';
    const s = await loadStoredSettings();
    await new Promise(resolve => chrome.storage.local.set({ ...s, userApiKey: apiKey, claudeModel: model }, resolve));
    await checkLicenseStatus();
  } else {
    el.textContent = `✗ ${result?.reason || 'Key did not work'}`;
    el.className = 'key-validation-status invalid';
  }
}

// ─── Pipeline UI ──────────────────────────────────────────────────────────────
function setLayerStatus(layer, status, text) {
  document.getElementById(`l${layer}-dot`).className = `status-dot ${status}`;
  document.getElementById(`l${layer}-text`).textContent = text;
}

function resetLayerStatuses() {
  [1, 2].forEach(n => setLayerStatus(n, '', 'Ready'));
  setLayerStatus(3, '', 'Waiting');
}

// ─── UI helpers ───────────────────────────────────────────────────────────────
function renderProfileCard(data) {
  const section = document.getElementById('profile-section');
  section.classList.remove('hidden');
  const name = data.name || 'Unknown';
  document.getElementById('profile-avatar').textContent = name.charAt(0).toUpperCase();
  document.getElementById('profile-name').textContent = name;
  document.getElementById('profile-headline').textContent = data.headline || '';
  document.getElementById('profile-company').textContent = data.currentCompany || '';
}

function renderMessage(payload, meta = null) {
  const text = typeof payload === 'string' ? payload : (payload?.generatedMessage || '');
  const strategyMeta = meta || (typeof payload === 'object' ? payload?.structuredMeta : null);

  document.getElementById('generated-message').value = text;
  document.getElementById('message-section').classList.remove('hidden');

  const stratBar = document.getElementById('message-strategy-bar');
  if (strategyMeta?.angle) {
    document.getElementById('strategy-angle-text').textContent = `🎯 Angle: ${strategyMeta.angle}`;
    document.getElementById('strategy-structure-text').textContent = strategyMeta.structure || '';
    stratBar.classList.remove('hidden');
  } else {
    stratBar.classList.add('hidden');
  }

  updateCharCount();
}

function hideMessage() {
  document.getElementById('message-section').classList.add('hidden');
}

async function handleCopy() {
  const text = document.getElementById('generated-message').value;
  if (!text) return;
  try { await navigator.clipboard.writeText(text); } catch (_) {
    const ta = document.getElementById('generated-message');
    ta.select(); document.execCommand('copy');
  }
  const btn = document.getElementById('copy-btn');
  btn.textContent = '✓ Copied!';
  setTimeout(() => { btn.textContent = 'Copy'; }, 2200);
}

function showCurrentStatus(msg, type = '') {
  const el = document.getElementById('status-message');
  el.textContent = msg;
  el.className = `status-bar${type ? ' status-' + type : ''}`;
  el.classList.remove('hidden');
}

function clearCurrentStatus() {
  const el = document.getElementById('status-message');
  el.classList.add('hidden');
  el.textContent = '';
}

function showSettingsStatus(msg, type = '') {
  const el = document.getElementById('settings-status');
  el.textContent = msg;
  el.className = `status-bar${type ? ' status-' + type : ''}`;
  el.classList.remove('hidden');
  setTimeout(() => el.classList.add('hidden'), 2500);
}

function setButtonLoading(btnId, labelId, spinnerId, loading, labelText) {
  document.getElementById(btnId).disabled = loading;
  document.getElementById(labelId).innerHTML = labelText;
  document.getElementById(spinnerId).classList.toggle('hidden', !loading);
}

// ─── Recent contacts ──────────────────────────────────────────────────────────
async function renderRecentContacts() {
  const contacts = await Cache.getContacts();
  const listEl = document.getElementById('recent-list');
  const emptyEl = document.getElementById('no-recent');
  const actionsEl = document.getElementById('recent-actions');
  listEl.innerHTML = '';
  if (contacts.length === 0) {
    emptyEl.classList.remove('hidden'); actionsEl.classList.add('hidden'); return;
  }
  emptyEl.classList.add('hidden'); actionsEl.classList.remove('hidden');
  contacts.forEach((c, i) => listEl.appendChild(buildContactCard(c, i)));
}

function buildContactCard(contact, idx) {
  const card = document.createElement('div');
  card.className = 'contact-card';
  const date = new Date(contact.timestamp).toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
  const preview = (contact.message || '').substring(0, 110) + ((contact.message || '').length > 110 ? '…' : '');
  card.innerHTML = `
    <div class="contact-header">
      <div class="contact-info">
        <div class="contact-name">${esc(contact.name || 'Unknown')}</div>
        <div class="contact-meta">${esc(contact.headline || contact.company || '')}</div>
      </div>
      <div class="contact-date">${esc(date)}</div>
    </div>
    <div class="contact-message-preview" id="prev-${idx}">${esc(preview)}</div>
    <div class="contact-message-full hidden" id="full-${idx}">${esc(contact.message || '')}</div>
    <div class="contact-actions">
      <button class="btn-link" id="expand-${idx}">Show full message</button>
      <button class="btn btn-sm btn-primary" id="copy-c-${idx}">Copy</button>
    </div>`;

  card.querySelector(`#expand-${idx}`).addEventListener('click', () => {
    const isHidden = card.querySelector(`#full-${idx}`).classList.contains('hidden');
    card.querySelector(`#prev-${idx}`).classList.toggle('hidden', isHidden);
    card.querySelector(`#full-${idx}`).classList.toggle('hidden', !isHidden);
    card.querySelector(`#expand-${idx}`).textContent = isHidden ? 'Show less' : 'Show full message';
  });

  card.querySelector(`#copy-c-${idx}`).addEventListener('click', async () => {
    await navigator.clipboard.writeText(contact.message || '').catch(() => {});
    const btn = card.querySelector(`#copy-c-${idx}`);
    btn.textContent = 'Copied!';
    setTimeout(() => { btn.textContent = 'Copy'; }, 2200);
  });

  return card;
}

// ─── Chrome messaging ─────────────────────────────────────────────────────────
function sendToBackground(msg) {
  return new Promise((resolve, reject) => {
    chrome.runtime.sendMessage(msg, (response) => {
      if (chrome.runtime.lastError) { reject(new Error(chrome.runtime.lastError.message)); return; }
      if (!response) { reject(new Error('No response from background.')); return; }
      if (!response.success) { reject(new Error(response.error || 'Background returned an error.')); return; }
      if (response.data !== undefined) { resolve(response.data); return; }
      if (response.generatedMessage !== undefined) { resolve(response.generatedMessage); return; }
      reject(new Error('Unexpected response: ' + JSON.stringify(Object.keys(response))));
    });
  });
}

// ─── Resume upload ────────────────────────────────────────────────────────────
function processResumeFile(file) {
  const statusEl = document.getElementById('resume-status');
  const dropArea = document.getElementById('file-upload-area');
  const fileLabel = document.getElementById('file-label');

  if (file.type !== 'application/pdf') {
    statusEl.textContent = 'Please upload a PDF file.';
    statusEl.className = 'resume-status error';
    statusEl.classList.remove('hidden');
    return;
  }

  if (file.size > 4 * 1024 * 1024) {
    statusEl.textContent = 'File too large — max 4MB.';
    statusEl.className = 'resume-status error';
    statusEl.classList.remove('hidden');
    return;
  }

  const reader = new FileReader();
  reader.onload = (e) => {
    const base64 = e.target.result.split(',')[1];
    pendingResume = { base64, fileName: file.name };
    fileLabel.textContent = file.name;
    dropArea.classList.add('has-file');
    statusEl.textContent = `${file.name} ready — click Save Settings to parse & cache.`;
    statusEl.className = 'resume-status pending';
    statusEl.classList.remove('hidden');
  };
  reader.onerror = () => {
    statusEl.textContent = 'Error reading file.';
    statusEl.className = 'resume-status error';
    statusEl.classList.remove('hidden');
  };
  reader.readAsDataURL(file);
}

function loadStoredSettings() {
  return new Promise(resolve => {
    chrome.storage.local.get(
      ['userApiKey', 'claudeModel', 'userName', 'userBio', 'resumeBase64', 'resumeFileName', 'resumeSummary'],
      resolve
    );
  });
}

function esc(str) {
  return String(str || '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
}